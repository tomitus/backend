package com.example.viikko2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Viikko2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
