package com.example.viikko2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Viikko2Application {

	public static void main(String[] args) {
		SpringApplication.run(Viikko2Application.class, args);
	}

}
