package viikko2.hello.teht1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Teht1Application {

	public static void main(String[] args) {
		SpringApplication.run(Teht1Application.class, args);
	}

}
